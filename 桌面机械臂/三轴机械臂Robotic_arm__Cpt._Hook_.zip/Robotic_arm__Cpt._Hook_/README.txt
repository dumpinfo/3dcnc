                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:658823
Robotic arm "Cpt. Hook" by thorgal is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

An attempt to make a high precision 3D robotic arm driven by NEMA 17 stepper motors. For the moment it will be just stored here. Please do not expect detailed description or instructions until I will have a working prototype. Feel free to download it, but be aware I cannot give you reliable support for steps I did not finished yet. Also be warned, that the parts may change eventually as the development will progress.  

The name is inspired by the lost arm of famous pirate. It is supposed to be attached to a desk and the manipulation area is going to be roughly 200mm deep, 200mm heigh and 270° sidewise. Motors with 400 steps per turn are going to be used along with 32 microstepping drivers. To eliminate backslash while gaining some more precision, T2.5 timing belts with 1:5 reduction ratio are going to drive the arms. Turning will have reduction rate 1:10. If motors will be able to stay on microsteps the precision of the movement would be close to 10μm in the designated area.  

As the calculation of three angles will be more complex than simple orthogonal movement, I expect that something more powerful than Arduino Mega is going to be used but search for suitable electronics is not over yet.  

I will be very glad for any help, support or usefull comment you would provide.  

Change log:  
2015-01-13 Version 1.0 designed. Turned out to be too massive, time and filament consuming. Slic3r failed to prepare supports as they were too light. Pulleys did not fit precisely T2.5 Belt.  
2015-01-29 Lighter design version 1.1 prepared. Supports are printable now. Some holes for M3 and M4 screws and nuts corrected. Place for belts redesigned.  
2015-02-10 Assembly version 1.2 uploaded. Made changes required for easier assembly of the robot. Also used typical lengths of metric screws. BoQ added.  
2015-03-16 Arm Assembled and mechanicaly operational although it is a mixture of different versions and prints from two 3D printers that are not calibrated quite the same. Pictures added to the gallery. Upward movement is somehow limited, system of drawbars have to be changed.  
2015-05-15 Test of movement showed that motor are running too hot due to the fact they have to be hold permanently. Model of fan holder uploaded. Friend of mine made a wonderfull app, which is simulating arm movement, calculating deviations and checking limits. With 1.8° motors and 32 microsteps we achieved deviations from desired position 0.025mm in X, 0.021mm in Y and 0.042mm in Z axis.  
2015-05-17 My friend Dan is making a fork of Marlin. So far we managed to move the arm with Ramp 1.4 and Atmega2560 but the shape of the printer was not well measured so it was a bit bumpy. Calibration desk was prepared, to to get the right numbers, that will have to figure in firmware.  
2015-05-18 New shape of swing was prepared along with new tool holder. Right now it is designed so it can hold even Jhead or E3D bowden extruder. There is no guarantee it will work as I prepared the mounting only according to drawings from internet but it is better than original 3mm hole. Slight changes in Arm 1 and 2 were done too.   
2015-06-20 Never ever forget your printed stuff in car at hot days. See the picture gallery and you will learn why :D. Good time to print version 1.3 and test the last set of arm models.

# Instructions

The design is prepared for T2.5 belts, ball bearings 608ZZ, 624ZZ and all screws and nuts are metric. I expect 0.15mm overflow to the sides, when printed, so the parts are prepared accordingly. Some parts have embeded supports for bridges made of 0.25mm thick walls. As per my experince such supports should be printable even with 0.5mm wide nozzle and are easier to remove than thicker ones.   

All the parts (including arms) should be printable on common PCB Heatbed 200x200mm, but this was not tested yet as for this I rather use semi professional 3D printer with bigger volume and better precision than my reprap.  

Already made some test prints with ABS at home. With 0.5 wide nozzle the pulleys are not coming out well as teeth are too round and shallow. But parts like, swing, drawbar, tool holder, body, motor holder and base are good enough. Arms and turntable should be definitely of PLA.  

In BoQ 1.2.xls is list of required material. Still there may be mistakes, especially in lengths of timing belts so please measure them before cutting.