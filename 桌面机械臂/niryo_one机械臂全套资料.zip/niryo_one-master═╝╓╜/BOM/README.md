# Niryo One BOM

The BOM\_StepByStep file shows you the BOM for each assembly step.

More resources :
* [Google Sheet containing the detailed Niryo One BOM per category](https://docs.google.com/spreadsheets/d/e/2PACX-1vRKZaMMaALGOu9jRb2pPY-hzO2wKbfK5dlxXRJX13jZtJ2pX-OD1FC3d_5NvjiSVNhvqQF9DdoSOLIK/pubhtml)
* [Niryo One Assembly guide](https://niryo.com/docs/niryo-one/assembly-guide/assemble-niryo-one/)
