                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:401000
3D Printer Robot Arm by evandene is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I redesigned the DARM Robot arm from seagull008 in order to reduce real play and virtual play. By eliminating or at least minimizing the play in bearing design and others, this robot arm becomes more likely capable to act as a 3D printer.
A single ball bearing has a lot of axial play. By having them as a tandem designed in, the axial play can be reduced to 0. (there are better solutions but this will do in this specific design)
I redesigned the base vertical axis(tandem bearing), the main axis (tandem bearing)and the secondary axis (tandem bearing).
I increased the "base" strength, added 240x2GT timing belts, modified the stepper adjustability in order to tie up the belts a little better.
I added a double stepper extruder with hot end in order for not having a push or pull force in the robot arm during filament feed. Heated bed etc. to be completed in a later stage.

Have fun.


# Print Settings

Printer: Own design and build Delta printer with BBB and BePrBo++ 
Rafts: No
Supports: No
Resolution: 0.2
Infill: 25%

Notes: 
Material used nGEN from Colorfabb