                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2567757
BLV mgn12 3D Printer mod for Anet A8 / AM8 / Prusa I3 clone by Blv is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

BLV mgn12 mod for Anet A8 / AM8
---
* The main purpose of this project is: converting your Anet A8 into an incredible 3d printer, using MGN12 rails fixed on an aluminium extrusion frame.

* This upgrade compatible with pheneeny's [AM8 mod](https://www.thingiverse.com/thing:2263216) with small changes. (Huge credit!)

* **Why mgn?**
The linear bearing and Delrin Wheel Gantry commonly used at most of low-mid 3d printers as a cheaper solution for linear motion. Its cheaper replacement for the expensive mgn rails BUT price is at the expense of accuracy and reliability. Well, linear guided rails (mgn rails) are much more rigid, extreme precise and smooth then linear bearing or Delrin. The linear rails lets you print with higher speed - shorting print time without compromising print quality.  The fact rails are fixed to frame prevents unwanted motion related to bent threaded rods or other axis's motion. There seems to be a good reason why they are mostly used with high end 3d printers.. 
So, i found [cheap chinese mgn rails at Aliexpress](https://www.aliexpress.com/item/12mm-Linear-Guide-MGN12-L-100-200-300-350-400-450-500-550-600-700-800/32861278496.html) and thought to myself why not?

IMPORTANT
----
**fixing the mgn rails can be very frustrating. it need to be perfectly aligned and straight.
else, it will give you a headache, so don't start this project without tons of patience.**

* **design flexibility and Source file**
I'm sharing with you the source file of this project in order to improve the design and make it even more better. you will find the STEP file inside the project zip.
Please follow the item license (under the Creative Commons - Attribution - Non-Commercial - Share Alike.).
* If you are using the STEP file, please don't forget to mark it as a Remix :)

* Also made for this project a [Build plate for simplify3d](https://www.thingiverse.com/thing:2598588)

**Please notice you may need to re-center bed coordinates via marlin configuration
or change Z extrusion position to center the hotbed**

Build it at your own risk.

[Latest video update](https://www.youtube.com/watch?v=VYAPbLh5rCg)
A quick peek at my project building progress.
sorry for all the exposed wires - i had to test it. first video after all axis's electronics had been connected. Next week i'll get the 400mm threaded rods and install the rest.
I had to reverse x-motor connector in this video beacuse mistakly i fixed the carriage screw on the back instead on the front (i fixed and uploaded the fixed x carriage).

* Seeing all of this great community members uploading photos and remixes worth all of the long hours that i have put into this project :) 
I will appreciate if you could please upload an "I made one" photos :)
Thank you guys !!!

# Changelog

- 3/2/18 Added a PDF file with all the offset measurements for Hotend and sensors.
- 7/1/18 All STEP files updated including: Main Printer, Cube carriage and MK3 carriage. 
(If you are using it, i will appreciate if you could please mark it as a REMIX)
- 6/1/18 New experimental Cube carriage supports V6/Clone BLtouch, 8mm/12mm Sensor (required 4010 blower fan). (inspired by CR-10)
- 6/1/18 New MK3 carriage made for [Prusa original MK3 nuzzle fan](https://www.thingiverse.com/thing:2712591) support BLtouch, 8mm/12mm Sensor. I Love this Carriage !!
- 6/1/18 New X-screw holder extended
- 6/1/18 New holders made for 30A/29A 360W power supply.
- 6/1/18 New X motor holder added a 4010 fan holder to cool the X motor on higher speeds.
- 6/1/18 New 4010 Spitfire style fan cover for the New X motor holder.
- 6/1/18 Modified the rear corners which allows threading cables through extrusions.
- 8.12/17 improved bed adapters for better slicing process.
- 25/11/17 added 2 type of Jigs that helps aligning the mgn12 rails
- 17/11/17  added a new experimental carriage adapter for Anet A8 Original carriage
STEP file updated ! (can be edited with any CAD software exp: fusion360)
added X-motor cover+cable holder (infill 65%+)
- 05/11 added X-Carriage for E3D Chimera Hotend
- 02/11 new LED strip holder (compatible with regular 9.8mm strip width)
new rubber feet mount instead of the tapped method. (Print with 60% infill)
new improved X-Carriage (added on both sides cable holder)
- 28/10 BOM updated
- 27/10 added Heated bed Belt locker (belt_lock_infill80.stl) (infill 80%+)
- 26/10 fixed x-carriage (the belt holder holes are now on front - reveres x motor not needed any more)
- 23/10 BOM list updated (added solution for AM8 with 440mm z extrusion)
- 22/10 added Cad Source file due to community request (BLV Mgn12 mod.step).
added BOM file (pdf)
added printing orientation images

<iframe src="//www.youtube.com/embed/VnbSI7vDNAc" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/VYAPbLh5rCg" frameborder="0" allowfullscreen></iframe>
Quick video: It's alive :) the first axis test..

<iframe src="//www.youtube.com/embed/DMExUBlhi_M" frameborder="0" allowfullscreen></iframe>

# Choose your Style

## Mod variations:

You have the ability to choose your own style:

1. **Anet A8 converted to [AM8](https://www.thingiverse.com/thing:2263216) (original height: 440mm)+ BLV mgn12 mod:**
If you are already a proud owner of an AM8 printer and don't want to change the orignal height, you will have to get a 350mm rails instead of 400mm .

2. **Anet A8 converted to [AM8](https://www.thingiverse.com/thing:2263216) + Higher Z-axis (height: 500mm) + BLV mgn12 mod:**
First you will have to build an AM8 with a small changes:
- instead of: 2x440mm 2040 extrusion > replace with: 2x500mm 2040 extrusion or bigger.
- instead of: 2x340mm 2040 extrusion > replace with: 4x364mm 2040 extrusion
- [get a longer threaded rods 400mm](http://s.click.aliexpress.com/e/bcAVj7LS).
obviously, you don't need to print all AM8 parts but some (more info at printing info section)

3. **Anet [AM8](https://www.thingiverse.com/thing:2263216) + Free style + BLV mgn12 mod:**
As i mentioned, the design is flexible and includes separated parts that can be fitted to your wish. if you want custom size printer with a bigger bed or higher Z-axis, please choose wisely your own extrusion size and attached the modular parts to your desired extrusion.


# Requirements & BOM

## Requirements:

1. [Anet A8 printer](https://www.gearbest.com/3d-printers-3d-printer-kits/pp_343643.html?lkid=14998155) > [AM8](https://www.thingiverse.com/thing:2263216)
3. Tools
2. Technical ability
4. spare time


## BOM - parts you need

clarification: BOM includes [AM8 BOM](https://www.thingiverse.com/thing:2263216).

* 7 x [Mgn12H Carriage (4 for Y-axis, 1 for X-axis, 2 for Z axis)](http://s.click.aliexpress.com/e/cnx4LZYG)
* 3 x 2040 extrusion 313mm (for top, front, back)
* 4 x 2040 extrusion 364mm (Y-axis)
* 1 x 2020 extrusion 420mm (x-axis)
* 2 x [608zz bearing **(optional: if you intend using the top threaded rod holders)**](http://s.click.aliexpress.com/e/bu6Impgy)
* 16 x HBLFSNF5 Corner Bracket Or [cheap ones that i used](http://s.click.aliexpress.com/e/ct6lCePW)
* 150 x [M5X10 Button Head Socket Cap Screw](http://s.click.aliexpress.com/e/bkaDwiQc)
* 8 x [M5x10 Socket Head Cap Screw](http://s.click.aliexpress.com/e/rdCEBs4)
* 6 x [M5x16 Socket Head Cap Screw](http://s.click.aliexpress.com/e/rdCEBs4)
* 4 x [M3X20 Socket Head Cap Screw](http://s.click.aliexpress.com/e/EAtFI4Y)
* 60 x [M3X8 Socket Head Cap Screw](http://s.click.aliexpress.com/e/EAtFI4Y)
* 1 x [M4X30 hex head (y-tensioner button)]((http://s.click.aliexpress.com/e/cofQXlYU))
* 6 x [M3X20 screw](http://s.click.aliexpress.com/e/EAtFI4Y)
* 1 x [M3X32 screw](http://s.click.aliexpress.com/e/bPa8ju3A)
* 20 x [M4X10 screw](http://s.click.aliexpress.com/e/cofQXlYU)
* 160 x [M5 T-nut or M5x.8 Square Nut](http://s.click.aliexpress.com/e/cE4VsD3a)
* 40 x [M3 T-nut](http://s.click.aliexpress.com/e/cE4VsD3a)
* 4 x [M3 nut](http://s.click.aliexpress.com/e/b6UeHSTq)
* 13 x [M3 Washer](http://s.click.aliexpress.com/e/bBzZ8BzO)
* 1 x [M3 nylock](http://s.click.aliexpress.com/e/GAEzFFa)
* 20 x [M4 nut](http://s.click.aliexpress.com/e/b6UeHSTq)
* 20 x [M4 washer](http://s.click.aliexpress.com/e/bBzZ8BzO)
* 6 x [Rubber Feet](http://s.click.aliexpress.com/e/c27ykKbA)
* 2 x [GT2 16T idler (3mm bore)](http://s.click.aliexpress.com/e/ccTBT0U0)
* 1 x 5 meters GT2 reinforced fiberglass belt 6mm wide pitch 2mm [The best belt i had](http://s.click.aliexpress.com/e/ciKvwgog)
* 1 x [PC4-M6 OD4mm](http://s.click.aliexpress.com/e/hwPdjgM) **(optional: if using greg's geard extruder)**

**for option 1 (original AM8 size):**
* 2 x 2040 extrusion 440mm (z axis)
* 3 x Mgn12 350mm rail (x & z axis)
* 2 x [Mgn12 400mm rail (y axis)](http://s.click.aliexpress.com/e/cnx4LZYG)

**for option 2 (extended z height):**
* 4 x [Mgn12 400mm rail](http://s.click.aliexpress.com/e/cnx4LZYG)
* 1 x Mgn12 360mm or 350mm rail
* 2 x 2040 extrusion 500mm (z axis)
* 2 x [Threaded Rods 400mm](http://s.click.aliexpress.com/e/bcAVj7LS)



## Additional electronics BOM

* 1 x [e3d v6 hotend or Clone](http://s.click.aliexpress.com/e/0VAEYg0)
Or
* 1 x e3d Chimera hot end
* [Silicone sock - helps keep the nozzle temperature steady](http://s.click.aliexpress.com/e/b3PFQhBw)
* [easy fast wires connectors](http://s.click.aliexpress.com/e/cq30k5Yk)

# What & How to print

**Part to print from this [BLV mgn12 mod](https://www.thingiverse.com/thing:2567757) project:**
print all except those optional parts:
- Y mount motor - (print this part only if you dont have the AM8 Y motor mount)
- Top z holders - (aka anti z-wobble) (holders may limit Z height and they are not really needed)
- Caliper Holder - (print only if you have a digital metal caliper)
- LCD case and brackets - (print it only if you have a reprap Discount LCD 12864 only, else use the original AM8 lcd case and brackets)

**Part to print from [AM8](https://www.thingiverse.com/thing:2263216):**
* 1 x 1_LCD_Base_Left (only if you are planing to use the original Anet A8 lcd)
* 1 x 1_LCD_Base_Right (only if you are planing to use the original Anet A8 lcd)
* 1 x 1_LCD_Case_Top (only if you are planing to use the original Anet A8 lcd)
* 1 x 1_PSU_Mount (for Original Anet PSU)
* 1 x 1_Wire_Holder
* 2 x 2_Bottom_Tee_Plate
* 2 x 2_Top_Corner_Plate
* 4 x 4_Bottom_Corner_Plate
* 1 x Anet_Board_Mount__With_Fan (dont print if you choose the electronics box)
OR
* 1 x Anet_Board_Mount_No_Fan (dont print if you choose the electronics box)

## Material and Infill

Inside zip file you will find a PDF file named: BLV mgn12 mod.pdf
which contain full spec of the Parts (name, material to print with and infill percentage).


## Printing orientation

Highly important: i added 4 pictures showing printing orientation of the prats.
the printing orientation is very important because it contributes to the strength of the items.

* make sure before printing that its calibrated since the dimension precision are crucial !

![Alt text](https://cdn.thingiverse.com/assets/df/c7/16/68/95/Printing_orientation.jpg)
view original size: open it in a new windows and save the image or use the pdf file inside the zip files

![Alt text](https://cdn.thingiverse.com/assets/1b/8c/a3/2a/8d/BLV_orie2.jpg)
view original size: open it in a new windows and save the image or use the pdf file inside the zip files

# Assembly instructions

1. Assemble the frame extrusion according to pheneeny's [AM8 mod](https://www.thingiverse.com/thing:2263216)
at the [AM8 mod files](https://www.thingiverse.com/thing:2263216) you will find also the prefect guide pheneeny made for assemby.

2. Assemble the BLV mgn12 mod according to assembly instructions that found in this project zip file. its a pdf file named:**BLV mgn12 mod.pdf**. the file contains sketch with all
the main parts.

3. [I made an assembly video in order to explain how to assemble:](https://youtu.be/inuvmbNgY5Y) Bed adapters, X-axis components, Cube carriage and  V6 carriage. On this video i mentioned a 5010 blower fan but i was wrong- I meant for 5015 fan (Thank you Craig).
**Please notice you may need re-center the hotend/bed coordinates via marlin configuration.**

# Additional Parts

## Additional Optional Parts

* [Greg's geard extruder](https://www.thingiverse.com/thing:18379)
* [Build plate of this project for simplify3d available here](https://www.thingiverse.com/thing:2598588)
* [Radial Fan Fang (including sensors adapters)](https://www.thingiverse.com/thing:2175956)
* [CPT_Spekkie AM8 Electronics Case](https://www.thingiverse.com/thing:2330654)
* [Devin's Knob with fine tuning dial](https://www.myminifactory.com/object/44169)
* [PapaJohn88's mount for Anet A6 lcd (rec by artistebot)](https://www.thingiverse.com/thing:2382917)
* [Handle For AM8](https://www.thingiverse.com/thing:2409747)
* Green PVC electrical tube for the extruder wires: sized 13mm - 1/2" can be on any electric shop. it can be called also: "Split Wire Loom" [can be found online here](https://www.aliexpress.com/wholesale?catId=0&initiative_id=SB_20180712230700&SearchText=Split+Wire+Loom) [Or here](https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Dtools&field-keywords=Split+Wire+Loom)

# MGN12 rails & Carriages extra info

## MGN Rails

Well, i used a cheap Chinese mgn12 rails from aliexpress cost 16.47$ each.
The store i bought it from named: ["RDC Official Store"](http://s.click.aliexpress.com/e/cnx4LZYG) via aliexpress. 
Since a lot of members have asked for a link, [here is the rails link which i bought](http://s.click.aliexpress.com/e/cnx4LZYG). They came quickly, each one was seperetely wrapped. Its was straight, smooth movements without jams! after i clean them it slide like a hot knife Through Butter.
Notice, that before that i bought from other store named: "linkcnc Store" and the rails was awful! it was a used rails, damaged and shorter then what i ordered. They ware so awful, that even after cleaning and lubricating it was still stuck and jammed.

## Cleaning and lubricating

notice that the mgn rails you'll get will not be smooth as it should be.
at the factory they lubricate it with a protecting oil that need to be cleaned away.
There are some videos on YouTube showing how to clean the carriage with WD-40.
don't forget that after cleaning both rails and carriage, you will have to lubricate it with sewing machine oil.
As for smoothness: Please ignore the method for testing smoothness but tilting the rail - its wrong! You want it to be smooth but not too much.
Also, since its a miniature rails, please don't use thick grease to lubricate.

## Adittional links

**Cleaning mgn12 carriage video:**
youtube.com/watch?v=luonzoH-xwQ
Although the video in russian language which i don't understand - its a pretty good video. just **use a container in order not to lose steel balls**

note: after assembling all steel balls, you will be left with empty space of one steel ball.

## Rails installation:

**INPORTANT**
* fixing the rail can very frustrating, you will have to re adjust it a few times until the rail will be leveled and straight.
* the mgn bed adapters needs to be fixes with screws to the heated bead carriage - screws must be tighten in cross like in anet a8 manual.
* take your time an adjust until it will be even from both sides then the motion will be smooth.
its very tricky and need a lot of patience.


# Small demonstration video

<iframe src="//www.youtube.com/embed/FWgkXiwj2UU" frameborder="0" allowfullscreen></iframe>
Note: The motor in the video is incompatible. it was installed only for taking the video and testing the weight.

![Alt text](https://cdn.thingiverse.com/assets/2d/21/ed/98/a5/BLV1.jpg)
view original size: open it in a new windows and save the image or use the pdf file inside the zip files

![Alt text](https://cdn.thingiverse.com/assets/a0/e1/62/70/27/BLV2.jpg)
view original size: open it in a new windows and save the image or use the pdf file inside the zip files