                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2985528
Easy to Assemble 2020 3D Printer by protosmart is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

English text soon...


Lista de Materiais (BOM):
1 Hotend E3DV6 Bowden
4 Nema 17
1 tubo 60 cm PTFE (Teflon)
1 conjunto extrusor MK8 Bowden
1 Perfil Alumínio 20x20 - 40 cm
1 Perfil Alumínio 20x20 - 30 cm
1 Perfil Alumínio 20x20 - 23 cm
1 Perfil Alumínio 20x20 - 45 cm
2 Eixo Retificado 8 mm - 40 cm
2 Eixo Retificado 8 mm - 45 cm
2 Eixo Retificado 8 mm - 30 cm
10 Rolamentos lineares LM8UU
1 Fuso TR8 30 cm
1 Castanha TR8
2 Ventoinhas 40x40x20 mm
2 Metros de Correia GT2 passo 2
1 Acoplamento Flexível 5 mm - 8 mm
2 Polias GT2 20 dentes interno 5 mm 
1 Sensor indutivo 8 mm
1 Ramps 1.4
1 Arduino Mega
4 Drivers de motor de passo
1 Chave liga-desliga
1 Entrada de conector P4 (Fonte)
1 Cabo USB
1 LCD FullGraphics Smart Controller (Opcional)
3 Rolamentos 608Z
3 Parafusos 8MM x 40 mm
3 Parafusos 1/4" x 2"
1 Fonte externa 12V - 10A (Caso sem mesa aquecida)
1 Mesa Graber/Prusa em MDF ou Metal
1,5 Metros Cabo AWG 22 duas vias
1 Metro Organizador de Cabos
x Parafuso M3
x Parafuso M6 x 10 mm
x Porcas quadradas Perfil Alumínio
x Parafuso de Madeira 3mm
x Parafuso madeira 2,2mm x 6 mm
x Lacre Plástico (fita Hellerman)

Alguns Tutoriais:
https://www.youtube.com/channel/UC7H5boX5J8LyQ1lkxHMSyNA