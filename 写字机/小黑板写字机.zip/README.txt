                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1590702
iBoardbot: an OPEN SOURCE internet remotely controlled drawing robot  by jjrobots is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

https://youtu.be/zr3JZYXoIVg
<h2><li><a href="http://jjrobots.com/the-iboardbot/">The iBoardbot:</li></h2>

The iBoardbot is an ARDUINO robot connected to the internet capable of writing texts and drawing with great precision. Also, it can erase in a quick and effective way. Send to your iBoardbot your information from any part of the world. As it has a multi-user interface you can also play and challenge your kids, use it as a collaborative notice board or as a twitter wall in your store window.
<h4></h4>
<h3>Features:</h3>
<h4>Drawing mode:</h4> It can precisely draw what you assign to it. Different users will be able to collaborate with the drawing at the same time from different devices and world places. No matter how far the drawer is; the drawing precision will be as if the drawer himself was holding the pen with his hands
<h4></h4>
<h4>Graphics mode:</h4> Upload and draw your own graphics using the iBoardbot´s webAPP!
<h4></h4>
<h4>Text mode:</h4> Send any text. The iBoardbot will adjust it to the right size so it can fit on the board and it will draw it using its own font. Just type it and click/tap on SEND
<h4></h4>
<h4>IFTTT integrated:</h4>  Why not send the subject of an email you just have received to the iBoardbot? Or the last SMS you got? Or the temperature of your home? Or the weather forecast? What about the last tweet from your favourite music band? or… there are as many possibilities as possible recipes. Some recipes created by users at http://jjrobots.com/iboardbots-ifttt-recipes/ (more to come!)
<h4></h4>
<h5>What IFTTT is:</h5>
http://jjrobots.com/iboardbot-ifttt-recipes-how-to/

UPDATE, may 2017: some 3D parts have been modified to make them simpler to print with any 3D printer

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: No
Resolution: 0.16
Infill: 0.35

Notes: 
There is no need to print the pieces with support. Everything printed with CURA (and no problems so far)

# How I Designed This

<h2>LIST OF MATERIALS:</h2>
·GT2 timing belt (two segments of 53+100 cms)
·pulley gt2 20 tooth
·608 bearing
·623 bearing
·Stainless steel round bar (8mmØ,450mm length)
·2x round anodised aluminium tube (6mmØ, 205 mm length)
·4x 30 cms servo cable extender
·2x 1.8deg HIGH QUALITY NEMA 17 Stepper motors (40mm length) (4.4Kg/cm torque)
·Motor cables (14+70 cms length do the job)
·2x SG90 servo
·Arduino Leonardo compatible
·B-robot Brain Shield 2.1 or...similar
·Power supply 12v/2A
·2x copper bushing (8x11×22)
·6mm M3 bolts
·16mm M3 bolts
·M3 nuts
·1x M3 self locking nuts

<p>OTHERS:</p>
-3mm wide/100mm long zip ties (~x10)
-5mmØ cable wrap (~90 cms)
-1x Staedtler MARKER (black)
-CLOUD SERVICE subscription

<h5>You can also buy everything(iBoardbot customizable KIT):<a href="http://jjrobots.com/the-iboardbot/"> here </a></h5> 

<h5>or create all the jjRobots with 
<a href="http://jjrobots.com/product/awesomeroboticskit/">the MOST AWESOME ROBOTICS KIT</a></h5> 

<h4>How to set it up?</h4>
Take a look to this link: http://jjrobots.com/iboardbot-assembly-instructions/


![Alt text](https://cdn.thingiverse.com/assets/79/b1/95/65/d2/kit_version_final.jpg)
                        The elements needed to create your own iBoardbot

![Alt text](https://cdn.thingiverse.com/assets/06/45/b9/71/8c/DIY_Brobot.gif)

## Info, code, assembly guide and community available at:

<h5>Code and 3D parts:</h5>
https://github.com/jjrobots/iBoardbot (code and 3D parts)
<h5>Assembly guide:</h5>
http://jjrobots.com/iboardbot-assembly-instructions/
<h5>How to control the iboardbot:</h5>
http://jjrobots.com/?p=2945
<h5>Community:</h5>
https://jjrobots.com/forum/


<iframe src="//www.youtube.com/embed/d6J0ijMG3jI&feature=youtu.be" frameborder="0" allowfullscreen></iframe>
B-robot EVO 2: another robot created using the same electronics and motors used in the iBoardbot

# The B.robot EVO 2 was created using the same elements

## B-robot EVO2. The fastest self balancing robot created with a 3D printer

If you have created a B-robot EVO 2, you already have the electronics and almost all the ancillary elements to create your iBoardbot! (yes, we have used the same items to create the drawing bot). Take a look to the B-robot EVO 2:
https://www.thingiverse.com/thing:2306541
and...<a href="http://jjrobots.com/product/awesomeroboticskit/">THE MOST AWESOME ROBOTICS KIT</a>

![Alt text](https://cdn.thingiverse.com/assets/e9/47/38/65/72/open.png)

<h4>The JJrobots have been seen in:</h4>

![Alt text](https://cdn.thingiverse.com/assets/6d/8a/09/75/e4/our_robots_have_appear_on.png)

![Alt text](https://cdn.thingiverse.com/assets/0e/c1/08/5d/df/awesome_KIT_photo_1.png)

<h5>CREATE DIFFERENT ROBOTS USING THE SAME ELECTRONICS AND ANCILLARY ELEMENTS WITH  <a href="http://jjrobots.com/product/awesomeroboticskit/">THE MOST AWESOME ROBOTICS KIT</a> </h5>