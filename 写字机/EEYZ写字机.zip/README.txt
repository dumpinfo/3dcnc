                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2936872
EEZYxyDRAW by daGHIZmo is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is an AxiDraw clone 

It is a cartesian drawing robot which was originally designed by EVIL MAD Scientist, but he was using a custom board EBB(EiBotBoard)
Almost at the same time Robottini released and published Cartesio a version using Arduino.

Later that other makers made some variations and released custom versions of the original bot being great source of inspiration for me.

Following I list a few :

24/03/2016 - Cartesio Robottini altervista
http://robottini.altervista.org/cartesio-low-cost-cartesian-plotter-robot

26/03/2016 - 4xiDraw Drawing machine - Misan
https://www.thingiverse.com/thing:1444216

27/04/2016 - Project: DrawingBot  - MakerC
https://www.thingiverse.com/thing:1517211  - 

27/01/2017 - DrawingBot with improved head and rotate pen (for fountain pen) - avanhanegem
https://www.thingiverse.com/thing:2058866

27/05/2017 - Drawing Robot - Arduino Uno + CNC Shield + GRBL  -  henryarnold 
https://www.thingiverse.com/thing:2349232

I made my own version redesigning all the mechanical parts and choose between some different softwares

tests video on YouTube https://youtu.be/PB58kp59Zds

# FIRMWARE / SOFTWARE

Firmware customization of GRBL comes from Robottini
https://github.com/robottini/grbl-servo

Inkscape to draw/import/convert and generate Gcode files (from extensions menu)
https://inkscape.org/

Inkscape extension for creating Gcode
https://jtechphotonics.com/?page_id=2012

Sourcerabbit Gcode sender
https://www.sourcerabbit.com/GCode-Sender/



# BOM hardware

HARDWARE BOM (Bill of Materials)

1x Arduino UNO R3
1x CNC shield
2x A4988 driver
2x Nema 17 stepper motors
2x Linear smooth rod M8 x 450mm, X AxiS
2x Linear smooth rod M8 x 350mm, Y axiS
2x Linear rod 3.5mm obtained using nails
2x M10 x 500 mm threaded rod
8x M10 flanged nuts
8x LM8UU linear bearing (also a 3d printed clone could be ok)
1x SG90 servo
8x F623ZZ flanged bearings
1x 2000mm GT2 belt (approx)
2x GT2 Pulley 16 teeth (also 20 teeth ok)
1x 12V 5A power supply
1x USB cable
some wires
some selftapping screws bolts & nuts